unsigned short current_duty, old_duty, current_duty1, old_duty1;
char uart_rd;
 #define R PORTD.RD0
 #define G PORTD.RD1
 #define B PORTD.RD2
 #define L1 PORTD.RD3
 #define L2 PORTD.RD4
 #define L3 PORTD.RD5
 #define L4 PORTD.RD6
void InitMain() {
  ANSEL  = 0;                         // Configure AN pins as digital
  ANSELH = 0;
  C1ON_bit = 0;                       // Disable comparators
  C2ON_bit = 0;             
    TRISD = 0;
  PORTD = 0;/*
  ADCON1 |= 0x0F;
  CMCON  |= 7; */
  PORTA = 255;
  TRISA = 255;                        // configure PORTA pins as input
  PORTB = 0;                          // set PORTB to 0
  TRISB = 0;                          // designate PORTB pins as output
  PORTC = 0;                          // set PORTC to 0
  TRISC = 0;                          // designate PORTC pins as output
  PWM2_Init(2000);                    // Initialize PWM1 module at 1KHz
  UART1_Init(9600);               // Initialize UART module at 9600 bps
  Delay_ms(100);                  // Wait for UART module to stabilize
  UART1_Write_Text("Start");
  UART1_Write(10);
  UART1_Write(13);
}
void Red(){
           R=1;G=0;B=0;L1=1;L2=1;L3=1;L4=1;
           }
void Blue(){
            R=0;G=1;B=0;L1=1;L2=1;L3=1;L4=1;
            }
void Green(){
             R=0;G=0;B=1;L1=1;L2=1;L3=1;L4=1;
             }
void secuencia2(){
                 R=0;G=0;B=0;L1=0;L2=0;L3=0;L4=0;
                  L1=1;L2=1;L3=0;L4=0;R=1;
                  Delay_ms(8);
                  L1=0;L2=0;L3=1;L4=1;R=0;G=1;
                  Delay_ms(8);
                  L1=1;L2=1;L3=0;L4=0;G=0;B=1;
                  Delay_ms(8);
                  L1=0;L2=0;L3=1;L4=1;B=0;R=1;
                  Delay_ms(8);
                  L1=1;L2=1;L3=0;L4=0;R=0;G=1;
                  Delay_ms(8);
                  L1=0;L2=0;L3=1;L4=1;G=0;B=1;
                  Delay_ms(8);
                  L1=1;L2=1;L3=0;L4=0;B=0;R=1;
                  Delay_ms(8);
                  R=0;G=0;B=0;L1=0;L2=0;L3=0;L4=0;
}
void secuencia1(){
            R=0;G=0;B=0;L1=0;L2=0;L3=0;L4=0;
            L1=1;R=1;
            Delay_ms(8);                      // slow down change pace a little
            L1=0;R=0;B=1;L2=1;
            Delay_ms(8);
            L2=0;B=0;G=1;L3=1;
            Delay_ms(8);
            L3=0;R=0;G=0;B=0;L4=1; //PRIMERA
            Delay_ms(8);
            L4=0;L1=1;B=1;
            Delay_ms(8);
            L1=0;B=0;G=1;L2=1;
            Delay_ms(8);
            R=0;G=0;B=0;L2=0;L3=1;
            Delay_ms(8);
            L3=0;R=1;L4=1; //SEGUNDA
            Delay_ms(8);
            L4=0;R=0;L1=1;G=1;
            Delay_ms(8);
            L1=0;R=0;G=0;B=0;L2=1;
            Delay_ms(8);
            L2=0;L3=1;R=1;
            Delay_ms(8);
            L3=0;B=0;L4=1;B=1; //TERCERA
            Delay_ms(8);
            L4=0;R=0;G=0;B=0;L1=1;
            Delay_ms(8);
            L1=0;L2=1;R=1;
            Delay_ms(8);
            L2=0;R=0;L3=1;B=1;
            Delay_ms(8);
            L3=0;B=0;L4=1;G=1;
            Delay_ms(8);
            R=0;G=0;B=0;L1=0;L2=0;L3=0;L4=0;
}
void main() {
            InitMain();
            current_duty  = 124;                 // initial value for current_duty
            PWM2_Start();                       // start PWM1
            PWM2_Set_Duty(current_duty);        // Set current duty for PWM1
            while (1) {
                       if (UART1_Data_Ready()) {     // If data is received,
                                                uart_rd = UART1_Read();     // read the received data,
                                                UART1_Write(uart_rd);       // and send data via UART
                                                }
                        switch(uart_rd){
                                        case '1':
                                                 current_duty=current_duty+20;                 // increment current_duty
                                                 PWM2_Set_Duty(current_duty);
                                                 secuencia1();
                                        break;
                                        case '2':
                                                 current_duty=current_duty-20;                 // increment current_duty
                                                 PWM2_Set_Duty(current_duty);
                                                 secuencia1();
                                        break;
                                        case '3':
                                                 current_duty=current_duty+20;                 // increment current_duty
                                                 PWM2_Set_Duty(current_duty);
                                                 secuencia2();
                                        break;
                                        case '4':
                                                 current_duty=current_duty-20;                 // increment current_duty
                                                 PWM2_Set_Duty(current_duty);
                                                 secuencia2();
                                        break;
                                        case '5':
                                                 Red();
                                        break;
                                        case '6':
                                                 Blue();
                                        break;
                                        case '7':
                                                 Green();
                                        break;
                                        case '8':
                                                 current_duty++;
                                                 PWM2_Set_Duty(current_duty);
                                        break;
                                        case '9':
                                                 current_duty--;
                                                 PWM2_Set_Duty(current_duty);
                                        break;
                                        }
            }
}