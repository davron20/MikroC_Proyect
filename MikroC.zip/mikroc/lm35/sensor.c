// LCD module connections
sbit LCD_RS at LATB4_bit;
sbit LCD_EN at LATB5_bit;
sbit LCD_D4 at LATB0_bit;
sbit LCD_D5 at LATB1_bit;
sbit LCD_D6 at LATB2_bit;
sbit LCD_D7 at LATB3_bit;

sbit LCD_RS_Direction at TRISB4_bit;
sbit LCD_EN_Direction at TRISB5_bit;
sbit LCD_D4_Direction at TRISB0_bit;
sbit LCD_D5_Direction at TRISB1_bit;
sbit LCD_D6_Direction at TRISB2_bit;
sbit LCD_D7_Direction at TRISB3_bit;
// End LCD module connections
char *abc[4];
void main() {
              int RTD;
              int * Luz;
              int num3;
              int num4;
              int shw[1];
              ADCON1 |= 0x0A; //an0~4 analogicas
              CMCON  |= 7;
              TRISA  = 0xFF;
              Lcd_Init();                // Inicializa LCD
             Lcd_Cmd(_Lcd_CURSOR_OFF);  // Desactivar curso
              while(1){
                                  RTD= ADC_Read(1);
                                  Luz=(int)(RTD/10);
                                  num3=(int)Luz%10;
                                  num4=(int)Luz-num3;
                                  num4=(int)num4/10;
                                  shw[1]=num3;
                                  shw[0]=num4;
                       IntToStr(Luz, abc);  //convierte enteros en carateres
                       Lcd_Out(1, 1, abc);  //  para mostrarlos en LCD.
                       }
}