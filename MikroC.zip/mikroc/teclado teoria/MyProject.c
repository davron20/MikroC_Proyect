int teclado(){
              while(1){
                       TEC:
                       TRISD = 0xF0;
                       PORTD = 1;
                       if(PORTD == 0x11){
                               return 1;
                               }
                       if(PORTD == 0x21){
                               return 4;
                               }
                       if(PORTD == 0x41){
                               return 7;
                               }
                       if(PORTD == 0x81){
                               return 14;
                               }
                       Delay_us(100);
                       PORTD = 2;
                       if(PORTD == 0x12){
                               return 2;
                               }
                       if(PORTD == 0x22){
                               return 5;
                               }
                       if(PORTD == 0x42){
                               return 8;
                               }
                       if(PORTD == 0x82){
                               return 0;
                               }
                       Delay_us(100);
                       PORTD = 4;
                       if(PORTD == 0x14){
                               return 3;
                               }
                       if(PORTD == 0x24){
                               return 6;
                               }
                       if(PORTD == 0x44){
                               return 9;
                               }
                       if(PORTD == 0x84){
                               return 15;
                               }
                       Delay_us(100);
                       PORTD = 8;
                       if(PORTD == 0x18){
                               return 10;
                               }
                       if(PORTD == 0x28){
                               return 11;
                               }
                       if(PORTD == 0x48){
                               return 12;
                               }
                       if(PORTD == 0x88){
                               return 13;
                               }
                       Delay_us(100);
                       goto TEC;
}
}
void main() {
             ADCON1 |= 0x0F;
             CMCON  |= 7;
             TRISA=0;
             while(1){
                      PORTA=teclado();
                      }
}