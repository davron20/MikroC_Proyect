unsigned short current_duty, old_duty, current_duty1, old_duty1;
char uart_rd;
unsigned char us;
#define M1 PORTB.RB0
#define M1_ PORTB.RB1
#define M2 PORTB.RB2
#define M2_ PORTB.RB3
void forward(){
                M1=1; M1_=0; M2=1;M2_=0;
                }
void der(){
           M1=1; M1_=0; M2=0;M2_=1;
           }
void izq(){
           M1=0;M1_=1; M2=1;M2_=0;
           }
void back(){
           M1=0;M1_=1; M2=0;M2_=1;
           }
void stop(){
            M1=0;M1_=0; M2=0;M2_=0;
            }
void InitMain() {
                 ADCON1 |= 0x0A; //an0~4 analogicas
                 TRISB = 0;
                 PORTB = 0;
                 PWM2_Init(5000);                    // Initialize PWM1 module at 1KHz
                 UART1_Init(9600);               // Initialize UART module at 9600 bps
                 Delay_ms(100);                  // Wait for UART module to stabilize
                 UART1_Write_Text("Start");
                 UART1_Write(10);
                 UART1_Write(13);
                 }
void main() {
             int temp,n1,n2,n3,x,y,zz;
             InitMain();
             current_duty  = 128;                 // initial value for current_duty
             PWM2_Start();                       // start PWM1
             PWM2_Set_Duty(current_duty);        // Set current duty for PWM1
             while(1){
                      PWM2_Set_Duty(current_duty);        // Set current duty for PWM1
                      if (UART1_Data_Ready()) {     // If data is received,
                                                uart_rd = UART1_Read();     // read the received data,
                                                }
                      temp=ADC_Read(0);
                      x=ADC_Read(1);
                      y=ADC_Read(2);
                      zz=ADC_Read(3);
                      temp=(int)(125*temp/256);
                      n1=(int)(temp%10);
                      n2=(int)(temp-n1)/10;
                      UART1_Write(48+n2);
                      UART1_Write(48+n1);
                      UART1_Write('%');
                      if(current_duty<100){
                                           n1=(int)(current_duty%10);
                                           n2=(int)(current_duty-n1)/10;
                                           UART1_Write(48+n2);
                                           UART1_Write(48+n1);
                      }
                      else{
                           n2=(int)(current_duty%100);
                           n3=(int) (n2%10);
                           n1= (int)(current_duty-n2)/100;
                           n2=(int)(n2-n3)/10;
                           UART1_Write(48+n1);
                           UART1_Write(48+n2);
                           UART1_Write(48+n3);
                           }
                      UART1_Write('x');
                      if(x<100){
                                           n1=(int)(x%10);
                                           n2=(int)(x-n1)/10;
                                           UART1_Write(48+n2);
                                           UART1_Write(48+n1);
                      }
                      else{
                           n2=(int)(x%100);
                           n3=(int) (n2%10);
                           n1= (int)(x-n2)/100;
                           n2=(int)(n2-n3)/10;
                           UART1_Write(48+n1);
                           UART1_Write(48+n2);
                           UART1_Write(48+n3);
                           }
                      UART1_Write('y');
                      if(y<100){
                                           n1=(int)(y%10);
                                           n2=(int)(y-n1)/10;
                                           UART1_Write(48+n2);
                                           UART1_Write(48+n1);
                      }
                      else{
                           n2=(int)(y%100);
                           n3=(int) (n2%10);
                           n1= (int)(y-n2)/100;
                           n2=(int)(n2-n3)/10;
                           UART1_Write(48+n1);
                           UART1_Write(48+n2);
                           UART1_Write(48+n3);
                           }
                      UART1_Write('z');
                      if(zz<100){
                                           n1=(int)(zz%10);
                                           n2=(int)(zz-n1)/10;
                                           UART1_Write(48+n2);
                                           UART1_Write(48+n1);
                      }
                      else{
                           n2=(int)(zz%100);
                           n3=(int) (n2%10);
                           n1= (int)(zz-n2)/100;
                           n2=(int)(n2-n3)/10;
                           UART1_Write(48+n1);
                           UART1_Write(48+n2);
                           UART1_Write(48+n3);
                           }
                      UART1_Write('t');
                      switch(uart_rd){
                                      case '1':
                                               forward();
                                      break;
                                      case '2':
                                               der();
                                      break;
                                      case '3':
                                               izq();
                                      break;
                                      case '4':
                                               back();
                                      break;
                                      case '5':
                                               stop();
                                      break;
                                      case '6':
                                               if(current_duty>1){
                                                                  current_duty--;
                                                                  uart_rd=' ';
                                                                  }
                                      break;
                                      case '7':
                                               if(current_duty<255){
                                                                  current_duty++;
                                                                  uart_rd=' ';
                                                                  }
                                      break;
                                     }
                                     
                      Delay_ms(100);}
             }