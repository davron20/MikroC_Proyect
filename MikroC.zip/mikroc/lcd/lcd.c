// LCD module connections
sbit LCD_RS at LATB4_bit;
sbit LCD_EN at LATB5_bit;
sbit LCD_D4 at LATB0_bit;
sbit LCD_D5 at LATB1_bit;
sbit LCD_D6 at LATB2_bit;
sbit LCD_D7 at LATB3_bit;

sbit LCD_RS_Direction at TRISB4_bit;
sbit LCD_EN_Direction at TRISB5_bit;
sbit LCD_D4_Direction at TRISB0_bit;
sbit LCD_D5_Direction at TRISB1_bit;
sbit LCD_D6_Direction at TRISB2_bit;
sbit LCD_D7_Direction at TRISB3_bit;
// End LCD module connections
  char *abc[3];
  void lcd(int x,char txt[]){
             ADCON1 |= 0x0F;
             CMCON  |= 7;
             Lcd_Init();                // Inicializa LCD
             Lcd_Cmd(_Lcd_CURSOR_OFF);  // Desactivar cursor
             Lcd_Out(2,1,"Grados:");
             Lcd_Out(1,6,txt);
             IntToStr(x, abc);  //convierte enteros en carateres
             Lcd_Out(2, 7, abc);  //  para mostrarlos en LCD

  }
  int teclado(){
              while(1){
                       TRISD = 0xF0;
                       PORTD = 1;
                       if(PORTD == 0x11){
                               return 1;
                               }
                       if(PORTD == 0x21){
                               return 4;
                               }
                       if(PORTD == 0x41){
                               return 7;
                               }
                       if(PORTD == 0x81){
                               return 14;
                               }
                       Delay_ms(1);
                       PORTD = 2;
                       if(PORTD == 0x12){
                               return 2;
                               }
                       if(PORTD == 0x22){
                               return 5;
                               }
                       if(PORTD == 0x42){
                               return 8;
                               }
                       if(PORTD == 0x82){
                               return 0;
                               }
                       Delay_ms(1);
                       PORTD = 4;
                       if(PORTD == 0x14){
                               return 3;
                               }
                       if(PORTD == 0x24){
                               return 6;
                               }
                       if(PORTD == 0x44){
                               return 9;
                               }
                       if(PORTD == 0x84){
                               return 15;
                               }
                       Delay_ms(1);
                       PORTD = 8;
                       if(PORTD == 0x18){
                               return 10;
                               }
                       if(PORTD == 0x28){
                               return 11;
                               }
                       if(PORTD == 0x48){
                               return 12;
                               }
                       if(PORTD == 0x88){
                               return 13;
                               }
                       Delay_ms(1);
}
}
   int i;
   int b;
   int ra;
   int rb;
   int piz;
void main() {
             b=0;
            ra=15;
            rb=0;
            piz=0;
            i=0;
            ADCON1 |= 0x0F;
            CMCON  |= 7;
            PORTC = 0; // sets port c to all 0
            TRISC = 0; //configures port c as output port
            TRISD = 0xFF;
            Lcd_Init();                // Inicializa LCD
            Lcd_Cmd(_Lcd_CURSOR_OFF);  // Desactivar cursor
            while(1){
                     A:
                     Lcd_Out(1,1,"A.Mover grado");
                     Lcd_Out(2,1,"B.Mover Numero");
                       switch(teclado()){
                                     case 3:do{
                                               switch(teclado()){
                                                             case  0:
                                                                   if(b<180)
                                                                             b++;
                                                                             lcd(b,"BASE +");
                                                                             break;
                                                             case  1:
                                                                     if(b>0)
                                                                             b--;
                                                                             lcd(b,"BASE -");
                                                                             break;
                                                             case  2:
                                                                     if(ra<180)
                                                                             ra++;
                                                                     lcd(ra,"BRAZO1+");
                                                                     break;
                                                             case  3:
                                                                     b=0;
                                                                     ra=15;
                                                                     rb=0;
                                                                     piz=0;
                                                                     i=0;
                                                                     lcd(0,"Restar");
                                                                     break;



                                                             }

                                               }while(1); break;
                                     case 7:
                                          break;
                                     }
                       }
                                     

}