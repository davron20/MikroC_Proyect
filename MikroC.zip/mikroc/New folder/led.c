void main() {
             ANSELA = 0;
             ANSELB = 0;
             TRISA = 0;             // Initialize PORTA as output
             TRISB = 0;             // Initialize PORTB as output
             LATA = 0;              // Set PORTA to zero
             LATB = 0;              // Set PORTB to zero
             while(1) {
                       LATA = ~PORTA;       // Invert PORTA value
                       LATB = ~PORTB;       // Invert PORTB value
                       Delay_ms(1000);
                       }
             }