unsigned char w,tx;
void trasmit_spi(tx){
                   PIR1.SSPIF=0;
                   w=SSPBUF;
                   SSPBUF=tx;
                   }
void main() {

}