/*int LED = 0;
int freq=0;
int ultdes=0;
bit flagFlanco; // Las variables de este tipo no pueden
                // inicializarse (0 por default)
sbit LCD_RS at RD6_bit;
sbit LCD_EN at RD5_bit;
sbit LCD_D4 at RD4_bit;
sbit LCD_D5 at RD3_bit;
sbit LCD_D6 at RD2_bit;
sbit LCD_D7 at RD1_bit;

sbit LCD_RS_Direction at TRISD6_bit;
sbit LCD_EN_Direction at TRISD5_bit;
sbit LCD_D4_Direction at TRISD4_bit;
sbit LCD_D5_Direction at TRISD3_bit;
sbit LCD_D6_Direction at TRISD2_bit;
sbit LCD_D7_Direction at TRISD1_bit;
int des;
int time;
char *abc[3];
void interrupt(){
  if(INTCON.TMR0IF){
                    INTCON.TMR0IF=0;
                    des++;
                    }
   if( INTCON.INT0IF == 1){
                           if(){
                                }
                           T0CON.TMR0ON =1 0; // Stop the timer
                           PORTD.RD0=~PORTD.RD0;
                           INTCON.INT0IF = 0;  //limpiar bandera
                           time=TMR0L;         //GUARDARA TIME
                           ultdes=des;
                           des=0;
                           TMR0L=0;           //clean
                           T0CON.TMR0ON = 1; // begin the timer
                        }

}
void main() {
            ADCON1 |= 0x0F;
            CMCON |= 7;
            TRISD = 0x00; // Puerto D como salidas
            PORTD.RD0 = 0;
            PORTD.RD7 = 0;
            des=0;
            INTCON.INT0IE = 1; // Interrupci�n externa INT0 habilitada
            INTCON.GIE = 1; // Habilita todas las interrupciones
            INTCON.TMR0IE = 1;
            INTCON2.INTEDG0 = 1; // INT0 en flanco de subida
            Lcd_Init();
            Lcd_Cmd(_LCD_CLEAR);
            Lcd_Cmd(_LCD_CURSOR_OFF);
            //TMR0 activado, prescaler 1:2
            T0CON = 0b10000000;
            while(1) {
                      Lcd_Cmd(_LCD_CLEAR);
                      freq=(int)(ultdes);
                      IntToStr(time, abc);
                      Lcd_Out(1,1,abc);
                      IntToStr(freq, abc);
                      Lcd_Out(2,2,abc);
                      delay_ms(100);
                     //Lcd_Out(1,1,"hola");
                     }
            } */
int LED = 0;
int contador
bit flagFlanco; // Las variables de este tipo no pueden
                // inicializarse (0 por default)

void interrupt(){

  if(INTCON.TMR0IE == 1){

   }

}

void main() {

ADCON1 |= 0x0F;
CMCON |= 7;
INTCON.INT0IE = 1; // Interrupci�n externa INT0 habilitada
INTCON.GIE = 1; // Habilita todas las interrupciones
INTCON2.INTEDG0 = 1; // INT0 en flanco de subida
TRISD = 0x00; // Puerto D como salidas


T0CON = 0b10000000;

  while(1) {
           PORTD.RD0 = flagFlanco;
           }
}