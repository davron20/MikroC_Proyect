void main() {
     while(1){
              ADCON1 |= 0x0F;
              CMCON  |= 7;
              TRISC = 0; //configures port D as output port
              TRISA = 0;
              PORTA =0;
              TRISB = 0;
              PORTB =0;
              TRISD = 0; //configures port D as output port
              PORTC = 0;
              PORTD = 0b01110110;
              PORTC = 1;
              delay_ms (1);
              PORTC = 0;
              PORTD = 0b00111111;
              PORTC = 2;
              delay_ms (2);
              PORTC = 0;
              PORTD = 0b00111000;
              PORTB = 127;
              delay_ms (3);
              PORTB = 0;
              PORTD = 0b01110111;
              PORTA = 127;
              delay_ms (1);
              }
            }