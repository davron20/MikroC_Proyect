int segmento(int numero) {
          switch(numero){ //senal para prender display
                         case 0:
                                return 63;
                         break;
                         case 1:
                                return 6;
                         break;
                         case 2:
                                return 91;
                         break;
                         case 3:
                                return 79;
                         break;
                         case 4:
                                return 102;
                         break;
                         case 5:
                                return 109;
                         break;
                         case 6:
                                return 125;
                         break;
                         case 7:
                                return 7;
                         break;
                         case 8:
                                return 127;
                         break;
                         case 9:
                                return 103;
                         break;
                         case 10:
                                 return 119;
                         break;
                         case 11:
                                 return 124;
                         break;
                         case 12:
                                 return 57;
                         break;
                         case 13:
                                 return 94;
                         break;
                         case 14:
                                 return 121;
                         break;
                         case 15:
                                 return 113;
                         break;
                         }
}
void main() {
             int enb;
             int LM;
             int *temp;
             int num1;
             int num2;
             int i=0;
             enb=0;
             ADCON1 |= 0x0A; //an0~4 analogicas
             CMCON  |= 7;
             TRISA  = 0xFF;
             TRISE=0;
             TRISD=0;
             while(1){
                      LM= ADC_Read(0);
                      temp =(int) (LM*125/256);
                      num1=(int)temp%10;
                      num2=(int)temp-num1;
                      num2=(int)num2/10;
                      for(i=0; i<100 ; i++){  //60
                                       PORTD=0;
                                       PORTE=0;
                                       PORTD=segmento(num2);
                                       PORTE=0b001;
                                       Delay_ms(8);
                                       PORTE=0;
                                       PORTD=segmento(num1);
                                       PORTE=0b010;
                                       Delay_ms(8);
                                       }
                      }
}