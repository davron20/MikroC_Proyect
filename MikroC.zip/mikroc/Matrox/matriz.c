void main() {
     ADCON1 |= 0x0F;
     CMCON  |= 7;
     TRISB=0;
     TRISD=0;
     while(1){

             PORTD=0b00011000;
             PORTB=0b10000001;
             PORTB=~PORTB;
             delay_ms(15);
             PORTD=0b00100100;
             PORTB=0b01000010;
             PORTB=~PORTB;
             delay_ms(15);
             PORTD=0b01000010;
             PORTB=0b00100100;
             PORTB=~PORTB;
             delay_ms(15);
             PORTD=0b10000001;
             PORTB=0b00011000;
             PORTB=~PORTB;
             delay_ms(15);
}            }