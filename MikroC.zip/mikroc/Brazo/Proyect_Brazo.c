// LCD module connections
sbit LCD_RS at LATB4_bit;
sbit LCD_EN at LATB5_bit;
sbit LCD_D4 at LATB0_bit;
sbit LCD_D5 at LATB1_bit;
sbit LCD_D6 at LATB2_bit;
sbit LCD_D7 at LATB3_bit;

sbit LCD_RS_Direction at TRISB4_bit;
sbit LCD_EN_Direction at TRISB5_bit;
sbit LCD_D4_Direction at TRISB0_bit;
sbit LCD_D5_Direction at TRISB1_bit;
sbit LCD_D6_Direction at TRISB2_bit;
sbit LCD_D7_Direction at TRISB3_bit;
int resultado,g,ena,fin;
int numero[3];
char *abc[3];
int i,j;
int ga,gb,gc,gd;
void motores(int q,int w,int e,int r){
                          ADCON1 |= 0x0F;
                          CMCON  |= 7;
                          TRISC = 0;
                          PORTC = 0;
                          TRISA = 0;
                          PORTA = 0;
                          delay_ms(1);
                          for(j=0;j<50;j++) {
                                            RC0_bit=1;
                                            for(i=0;i<q;i++) {
                                                             delay_us(11);
                                                             }
                                            RC0_bit=0;
                                            RC1_bit=1;
                                            for(i=0;i<w;i++) {
                                                             delay_us(11);
                                                             }
                                            RC1_bit=0;
                                            RA0_bit=1;
                                            for(i=0;i<e;i++) {
                                                             delay_us(11);
                                                             }
                                            RA0_bit=0;
                                            RA1_bit=1;
                                            delay_us(500);
                                            for(i=0;i<r;i++) {
                                                             delay_us(11);
                                                        }
                                            RA1_bit=0;
                                            delay_ms(10);
                                            }
}

int teclado(){
              while(1){
                       TRISD = 0xF0;
                       PORTD = 1;
                       if(PORTD == 0x11){
                               return 1;
                               }
                       if(PORTD == 0x21){
                               return 4;
                               }
                       if(PORTD == 0x41){
                               return 7;
                               }
                       if(PORTD == 0x81){
                               return 14;
                               }
                       Delay_us(100);
                       PORTD = 2;
                       if(PORTD == 0x12){
                               return 2;
                               }
                       if(PORTD == 0x22){
                               return 5;
                               }
                       if(PORTD == 0x42){
                               return 8;
                               }
                       if(PORTD == 0x82){
                               return 0;
                               }
                       Delay_us(100);
                       PORTD = 4;
                       if(PORTD == 0x14){
                               return 3;
                               }
                       if(PORTD == 0x24){
                               return 6;
                               }
                       if(PORTD == 0x44){
                               return 9;
                               }
                       if(PORTD == 0x84){
                               return 15;
                               }
                       Delay_us(100);
                       PORTD = 8;
                       if(PORTD == 0x18){
                               return 10;
                               }
                       if(PORTD == 0x28){
                               return 11;
                               }
                       if(PORTD == 0x48){
                               return 12;
                               }
                       if(PORTD == 0x88){
                               return 13;
                               }
                       Delay_us(100);
                       motores(ga,gb,gc,gd);
                       return 16;
                       }
}

int leerN(){
            A:
             resultado =0;
             g=0;
             while(1){
                     if(teclado()!=16 && ena==0){
                               g++;
                               numero[g]=teclado();
                               ena=1;
                               }
                     if(teclado()==16){
                                ena=0;
                     }
                     if(g==3){
                                resultado= numero[3]+ numero[2]*10 +numero[1]*100;
                                if(resultado >=180){ resultado = 180;
                                                    }
                                return resultado;
                               }
                     }

}

void main() {
             ADCON1 |= 0x0F;
             CMCON  |= 7;
             ga = 0;
             gb=0;
             gc=0,
             gd=0;
             Lcd_Cmd(_LCD_CURSOR_OFF);

             I:
             Lcd_Init();
             motores(ga,gb,gc,gd);
             Lcd_Out(1, 1, "*mover por grado");
             Lcd_Out(2, 1, "#mover por paso");
             while(1){ motores(ga,gb,gc,gd);
                       switch(teclado()){
                                         case 14:
                                                 A:
                                                 motores(ga,gb,gc,gd);
                                                 Lcd_Cmd(_LCD_CLEAR);
                                                 Lcd_Out(1, 1, "Elija Motor");
                                                 while(1){ motores(ga,gb,gc,gd);
                                                          switch(teclado()){
                                                                            case 10:
                                                                                    Lcd_Cmd(_LCD_CLEAR);
                                                                                    Delay_ms(500);
                                                                                    Lcd_Cmd(_LCD_CLEAR);
                                                                                    Lcd_Out(1, 1, "Grados A");
                                                                                    ga = leerN();
                                                                                    IntToStr(ga, abc);
                                                                                    Lcd_Out(2,1,abc);
                                                                                    motores(ga,gb,gc,gd);
                                                                            break;

                                                                            case 11:
                                                                                    motores(ga,gb,gc,gd);
                                                                                    Delay_ms(500);
                                                                                    Lcd_Cmd(_LCD_CLEAR);
                                                                                    Lcd_Out(1, 1, "Grados B");
                                                                                    gb = leerN();
                                                                                    IntToStr(gb, abc);
                                                                                    Lcd_Out(2,1,abc);
                                                                                    motores(ga,gb,gc,gd);
                                                                            break;

                                                                            case 12:motores(ga,gb,gc,gd);
                                                                                    Delay_ms(500);
                                                                                    Lcd_Cmd(_LCD_CLEAR);
                                                                                    Lcd_Out(1, 1, "Grados C");
                                                                                    gc = leerN();
                                                                                    IntToStr(gc, abc);
                                                                                    Lcd_Out(2,1,abc);
                                                                                    motores(ga,gb,gc,gd);
                                                                            break;

                                                                            case 13:motores(ga,gb,gc,gd);
                                                                                    Delay_ms(500);
                                                                                    Lcd_Cmd(_LCD_CLEAR);
                                                                                    Lcd_Out(1, 1, "Grados D");
                                                                                    gd = leerN();
                                                                                    IntToStr(gd, abc);
                                                                                    Lcd_Out(2,1,abc);
                                                                                    motores(ga,gb,gc,gd);
                                                                            break;
                                                                            case 14:  goto A;
                                                                            break;
                                                                            case 15:  goto I;
                                                                            break;
                                                                            case 16:
                                                                            break;
                                                                            default:
                                                                                    Lcd_Cmd(_LCD_CLEAR);
                                                                                    Lcd_Out(1, 1, "ERROR");
                                                                            }
                                                          }
                                                 break;
                                         case 15:
                                                 B:
                                                 Lcd_Cmd(_LCD_CLEAR);
                                                 Lcd_Out(1, 1, "Elija Motor");
                                                 while(1){ motores(ga,gb,gc,gd);
                                                          switch(teclado()){
                                                                            case 10:
                                                                                    Lcd_Cmd(_LCD_CLEAR);
                                                                                    while(1){
                                                                                             if(teclado()==1){ ga=ga+10;
                                                                                                                }
                                                                                             if(teclado()==2){  ga=ga-10;
                                                                                                                }
                                                                                             if(teclado()==0){ goto B;
                                                                                                                }
                                                                                             motores(ga,gb,gc,gd);
                                                                                             Lcd_Out(1, 1, "Grados A");
                                                                                             IntToStr(ga, abc);
                                                                                             Lcd_Out(2,1,abc);
                                                                                    }
                                                                            break;
                                                                            case 11:
                                                                                   Lcd_Cmd(_LCD_CLEAR);
                                                                                   while(1){
                                                                                             motores(ga,gb,gc,gd);
                                                                                             if(teclado()==1){ gb=gb+10;
                                                                                                                }
                                                                                             if(teclado()==2){  gb=gb-10;
                                                                                                                }
                                                                                             if(teclado()==0){ goto B;
                                                                                                                }
                                                                                             motores(ga,gb,gc,gd);
                                                                                             Lcd_Out(1, 1, "Grados B" );
                                                                                             IntToStr(gb, abc);
                                                                                             Lcd_Out(2,1,abc);
                                                                                             motores(ga,gb,gc,gd);
                                                                                    }
                                                                            break;
                                                                            case 12:
                                                                                  Lcd_Cmd(_LCD_CLEAR);
                                                                                  while(1){  motores(ga,gb,gc,gd);
                                                                                             if(teclado()==1){ gc=gc+10;
                                                                                                                }
                                                                                             if(teclado()==2){  gc=gc-10;
                                                                                                                }
                                                                                             if(teclado()==0){ goto B;
                                                                                                                }
                                                                                             Lcd_Out(1, 1, "Grados C");
                                                                                             IntToStr(gc, abc);
                                                                                             Lcd_Out(2,1,abc);
                                                                                             motores(ga,gb,gc,gd);
                                                                                    }
                                                                            break;
                                                                            case 13:
                                                                                    Lcd_Cmd(_LCD_CLEAR);
                                                                                    while(1){
                                                                                             if(teclado()==1){ gd=gd+10;
                                                                                                                }
                                                                                             if(teclado()==2){  gd=gd-10;
                                                                                                                }
                                                                                             if(teclado()==0){ goto B;
                                                                                             Lcd_Out(1, 1, "Grados D");
                                                                                             IntToStr(gd, abc);
                                                                                             Lcd_Out(2,1,abc);
                                                                                             motores(ga,gb,gc,gd);
                                                                                                                }
                                                                                    }
                                                                            break;
                                                                            case 14:  goto I;
                                                                            break;
                                                                            case 15:  goto B;
                                                                            break;
                                                                            case 16:
                                                                            break;
                                                                            default:
                                                                                    Lcd_Cmd(_LCD_CLEAR);
                                                                                    Lcd_Out(1, 1, "ERROR");
                                                                            }
                                                 }
                                                 break;
                                         case 16:
                                                 goto I;
                                                 break;
                                         default:
                                                 Lcd_Cmd(_LCD_CLEAR);
                                                 Lcd_Out(2, 1, "invalida");
                                         }
                         }
             }