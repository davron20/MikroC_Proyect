#define doo PORTD.RD0
#define re PORTD.RD1
#define mi PORTD.RD2
#define fa PORTD.RD3
#define sol PORTD.RD4
#define la PORTD.RD5
#define si PORTD.RD6
#define enb PORTB.RB0
#define FREQ 20000000    // Frequency = 20MHz
#define baud 9600
#define spbrg_value (((FREQ/64)/baud)-1)
unsigned short current_duty;
char uart_rd;
unsigned char serial_data;
void tx_data(unsigned char data1)
{
    TXREG=data1;                                     // Store data in Transmit register
    while(PIR1.TXIF==0);                             // Wait until TXIF gets low
}


unsigned char rx_data(void)
{
    while(PIR1.RCIF==0);                            // Wait until RCIF gets low
    return RCREG;                                   // Retrieve data from reception register
}
void InitMain() {
                 ADCON1 |= 0x0A; //an0~4 analogicas
                 TRISB = 0;
                 PORTB = 0;
                 SPBRG=spbrg_value;                                // Fill the SPBRG register to set the Baud Rate
                 RCSTA.SPEN=1;                                     // To activate Serial port (TX and RX pins)
                 TXSTA.TXEN=1;                                     // To enable transmission
                 RCSTA.CREN=1;                                     // To enable continuous reception
                 T2CON.TMR2ON = 1;  //Timer2 is on
                 T2CON.T2CKPS1 = 1;   // prescaler 16
                 T2CON.T2CKPS0 = 1;      // prescaler 16
                 CCP1CON.CCP1M0 = 1;       //PWM mode: P1A, P1C active-low; P1B, P1D active-low
                 CCP1CON.CCP1M1 = 1;
                 CCP1CON.CCP1M2 = 1;    //X
                 CCP1CON.CCP1M3 = 1;    //X
                 CCPR2L=156;
                 /*UART1_Init(9600);               // Initialize UART module at 9600 bps
                 Delay_ms(100);                  // Wait for UART module to stabilize
                 UART1_Write_Text("Start");
                 UART1_Write(10);
                 UART1_Write(13); */
                 }

void main(){
            InitMain();
            current_duty  = 124;                 // initial value for current_duty
            A:
            CCPR1L= current_duty;
            while(1){
                     /*if (UART1_Data_Ready()) {     // If data is received,
                                                uart_rd = UART1_Read();     // read the received data,
                                                UART1_Write(uart_rd);       // and send data via UART
                                                } */
                     uart_rd =   rx_data();
                     if(doo==1){
                               current_duty=22; //DO  14%
                               enb=1;
                               goto A;
                               }
                     if(re==1){
                               current_duty=44; //RE 28%
                               enb=1;
                               goto A;
                               }
                     if(mi==1){
                               current_duty=66; //MI 42%
                               enb=1;
                               goto A;
                               }
                     if(fa==1){
                               current_duty=87; //FA 56%
                               enb=1;
                               goto A;
                               }
                     if(sol==1){
                               current_duty=109; //SOL  70%
                               enb=1;
                               goto A;
                               }
                     if(la==1){
                               current_duty=131; //LA 84%
                               enb=1;
                               goto A;
                               }
                     if(si==1){
                               current_duty=153; //SI 98%
                               enb=1;
                               goto A;
                               }

                     }
            }