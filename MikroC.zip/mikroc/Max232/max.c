char uart_rd;
int ctrlInicio=20;
int ctrl=0;
void PrimerMov(void)
{
    PORTB.RB0=1;
    delay_us(1700);        //*Sube el 2do servo para quedar paralelo al suelo.
    PORTB.RB0=0;
    delay_ms(18);
}

void SegundoMov(void)
{
        PORTB.RB0=1;
        delay_us(1700);  //*Refresca el 2do servo.
        PORTB.RB0=0;
        //delay_ms(20);
        PORTE.RE0=1;
        delay_us(1400); //*Acomoda el 3er servo paralelo al suelo.
        PORTE.RE0=0;
        delay_ms(18);
}

void TercerMov(void)
{
       PORTB.RB0=1;
       delay_us(2000);  //*Baja el 2do servo para que el Sensor de color reconozca las cajas.
       PORTB.RB0=0;
       delay_ms(18);
}

void DesplazaZ(void)
{
        PORTB.RB0=1;
        delay_us(2000); //*Refresca el 2do servo.
        PORTB.RB0=0;
        PORTB.RB7=1;
        delay_us(1700); //*Se mueve el 1er servo a la secci�n Z de las cajas.
        PORTB.RB7=0;
        delay_ms(18);
}

void DesplazaY(void)
{
        PORTB.RB0=1;
        delay_us(2000);  //*Se refresca el 2do servo.
        PORTB.RB0=0;
        delay_ms(10);
        PORTB.RB7=1;
        Delay_us(1200);  //*Se desplaza el 1er servo hac�a la secci�n de cajas Y.
        PORTB.RB7=0;
        Delay_ms(8);
}

void DesplazaX(void)
{
        PORTB.RB0=1;
        delay_us(2000); //*Refresca el 2do servo.
        PORTB.RB0=0;
        delay_ms(20);
        PORTB.RB7=1;
        delay_us(700); //*Desplaza el 1er servo hac�a la secci�n X de cajas.
        PORTB.RB7=0;
        delay_ms(20);
}
void abrir(void){
        PORTB.RB1=1;
        delay_us(100); //*Desplaza el 1er servo hac�a la secci�n X de cajas.
        PORTB.RB1=0;
        delay_ms(20);
}
void cerrar(void){
        PORTB.RB1=1;
        delay_us(1500); //*Desplaza el 1er servo hac�a la secci�n X de cajas.
        PORTB.RB1=0;
        delay_ms(20);
}
void main() {
              ADCON1 |= 0x0F;
              CMCON  |= 7;
              TRISB=0;
              TRISE=0;
              PORTB=0;
              PORTE=0;
              UART1_Init(9600);               // Initialize UART module at 9600 bps
              Delay_ms(100);                  // Wait for UART module to stabilize
              UART1_Write_Text("Start");
              UART1_Write(10);
              UART1_Write(13);
              while (1) {                     // Endless loop
                        if (UART1_Data_Ready()) {     // If data is received,
                                                uart_rd = UART1_Read();     // read the received data,
                                                UART1_Write(uart_rd);       // and send data via UART
                                                }
                        switch(uart_rd){
                                        case '0':
                                                 PrimerMov();
                                                 abrir();
                                        break;
                                        case '1':
                                                 SegundoMov();
                                        break;
                                        case '2':
                                                 TercerMov();
                                        break;
                                        case '3':
                                                 DesplazaZ();
                                                 abrir();
                                        break;
                                        case '4':
                                                 DesplazaZ();
                                                 cerrar();
                                        break;
                                        case '5':
                                                 DesplazaY();
                                                 cerrar();
                                        break;
                                        case '6':
                                                 DesplazaX();
                                                 cerrar();
                                        break;
                                        case '7':
                                                 abrir();
                                        break;
                                        case '8':
                                                 cerrar();
                                        break;
                                        }
                        }

             }