// LCD module connections
sbit LCD_RS at LATB4_bit;
sbit LCD_EN at LATB5_bit;
sbit LCD_D4 at LATB0_bit;
sbit LCD_D5 at LATB1_bit;
sbit LCD_D6 at LATB2_bit;
sbit LCD_D7 at LATB3_bit;

sbit LCD_RS_Direction at TRISB4_bit;
sbit LCD_EN_Direction at TRISB5_bit;
sbit LCD_D4_Direction at TRISB0_bit;
sbit LCD_D5_Direction at TRISB1_bit;
sbit LCD_D6_Direction at TRISB2_bit;
sbit LCD_D7_Direction at TRISB3_bit;

int teclado(){
                       TEC:
                       TRISD = 0xF0;
                       PORTD = 1;
                       if(PORTD == 0x11){
                               return 1;
                               }
                       if(PORTD == 0x21){
                               return 4;
                               }
                       if(PORTD == 0x41){
                               return 7;
                               }
                       if(PORTD == 0x81){
                               return 14;
                               }
                       Delay_us(100);
                       PORTD = 2;
                       if(PORTD == 0x12){
                               return 2;
                               }
                       if(PORTD == 0x22){
                               return 5;
                               }
                       if(PORTD == 0x42){
                               return 8;
                               }
                       if(PORTD == 0x82){
                               return 0;
                               }
                       Delay_us(100);
                       PORTD = 4;
                       if(PORTD == 0x14){
                               return 3;
                               }
                       if(PORTD == 0x24){
                               return 6;
                               }
                       if(PORTD == 0x44){
                               return 9;
                               }
                       if(PORTD == 0x84){
                               return 15;
                               }
                       Delay_us(100);
                       PORTD = 8;
                       if(PORTD == 0x18){
                               return 10;
                               }
                       if(PORTD == 0x28){
                               return 11;
                               }
                       if(PORTD == 0x48){
                               return 12;
                               }
                       if(PORTD == 0x88){
                               return 13;
                               }
                       Delay_us(100);
                       goto TEC;
}
int resultado,g,ena;

 char *abc[3];
void main() {
             ADCON1 |= 0x0F;
             CMCON  |= 7;
             Lcd_Init();
             Lcd_Cmd(_LCD_CURSOR_OFF);
             Lcd_Out(1, 1, "HolA Mundo");
                           Delay_ms(100);
             while(1){
                           switch(teclado()){
                                             case 10:
                                                     Lcd_Out(1, 0, "HolA Mundo");
                                                     Delay_ms(100);
                                             break;
                                             case 11:
                                                     Lcd_Out(1, 0, "Hello world");
                                                     Delay_ms(100);
                                             break;
                                             case 12:
                                                     Lcd_Out(1, 0, "nota de 5");
                                                     Delay_ms(100);
                                             break;
                                             case 13:
                                                     Lcd_Out(1, 0, "ola ");
                                                     Delay_ms(100);
                                             break;
                                             case 14:
                                                     Lcd_Out(2, 7, "Segunda fila");
                                                     Delay_ms(100);
                                             break;
                                             case 15:
                                                     Lcd_Cmd(_LCD_CLEAR);
                                             break;
                                             }
                            }              // Clear display

                      
             }