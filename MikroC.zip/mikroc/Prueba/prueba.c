sbit LCD_RS at LATB4_bit;
sbit LCD_EN at LATB5_bit;
sbit LCD_D4 at LATB0_bit;
sbit LCD_D5 at LATB1_bit;
sbit LCD_D6 at LATB2_bit;
sbit LCD_D7 at LATB3_bit;

sbit LCD_RS_Direction at TRISB4_bit;
sbit LCD_EN_Direction at TRISB5_bit;
sbit LCD_D4_Direction at TRISB0_bit;
sbit LCD_D5_Direction at TRISB1_bit;
sbit LCD_D6_Direction at TRISB2_bit;
sbit LCD_D7_Direction at TRISB3_bit;
int i;
int j;
int k;
int t;
char *abc[3];
int teclado(){
              while(1){
                       TRISD = 0xF0;
                       PORTD = 1;
                       if(PORTD == 0x11){
                               return 1;
                               }
                       if(PORTD == 0x21){
                               return 4;
                               }
                       if(PORTD == 0x41){
                               return 7;
                               }
                       if(PORTD == 0x81){
                               return 14;
                               }
                       Delay_us(10);
                       PORTD = 2;
                       if(PORTD == 0x12){
                               return 2;
                               }
                       if(PORTD == 0x22){
                               return 5;
                               }
                       if(PORTD == 0x42){
                               return 8;
                               }
                       if(PORTD == 0x82){
                               return 0;
                               }
                       Delay_us(10);
                       PORTD = 4;
                       if(PORTD == 0x14){
                               return 3;
                               }
                       if(PORTD == 0x24){
                               return 6;
                               }
                       if(PORTD == 0x44){
                               return 9;
                               }
                       if(PORTD == 0x84){
                               return 15;
                               }
                       Delay_us(10);
                       PORTD = 8;
                       if(PORTD == 0x18){
                               return 10;
                               }
                       if(PORTD == 0x28){
                               return 11;
                               }
                       if(PORTD == 0x48){
                               return 12;
                               }
                       if(PORTD == 0x88){
                               return 13;
                               }
                       Delay_us(10);
                       return 16;
}
}

void main() {
             ADCON1 |= 0x0F;
             CMCON  |= 7;
             TRISC = 0;
             PORTC = 0;
             Lcd_Init();
             while(1){
                      switch (teclado()){
                                         case 1:RC0_bit=1;
                                                delay_ms(1);
                                                RC0_bit=0;
                                                delay_ms(19);
                                         break;
                                         case 2:RC0_bit=1;
                                                delay_us(1500);
                                                RC0_bit=0;
                                                delay_us(18500);
                                         break;
                                         case 3:RC0_bit=1;
                                                delay_us(1800);
                                                RC0_bit=0;
                                                delay_us(18200);
                                                 break;
                                         case 4:RC0_bit=1;
                                                delay_us(1900);
                                                RC0_bit=0;
                                                delay_us(18100);
                                                 break;
                                         case 5:RC0_bit=1;
                                                delay_us(1400);
                                                RC0_bit=0;
                                                delay_us(18600);
                                                 break;
                                          case 6:RC0_bit=1;
                                                delay_us(1200);
                                                RC0_bit=0;
                                                delay_us(18800);
                                                 break;
                                          case 7:RC0_bit=1;
                                                delay_us(1100);
                                                RC0_bit=0;
                                                delay_us(18900);
                                                 break;
                                         case 10:RC0_bit=1;
                                                delay_ms(2);
                                                RC0_bit=0;
                                                delay_ms(18);
                                                break;
                                       }
                      }

}