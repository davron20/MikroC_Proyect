int numero(int numero,int fila){  //LETRA A DIBUJAR  ~ Informa que fila tiene que dibujar
    switch(numero){
                   case 0: //dibja la A
                   switch(fila){
                          case 0:
                                return 0x00;
                          break;
                          case 1:
                               return 0x3C;
                          break;
                          case 2:
                               return 0x24;
                          break;
                          case 3:
                               return 0x24;
                          break;
                          case 4:
                               return 0x3C;
                          break;
                          case 5:
                               return 0x24;
                          break;
                          case 6:
                               return 0x24;
                          break;
                          case 7:
                               return 0;
                          break;
                          }
                   break;
                   case 1: // dibuja la B
                   switch(fila){
                          case 0:
                                return 0x1C;
                          break;
                          case 1:
                               return 0x24;
                          break;
                          case 2:
                               return 0x24;
                          break;
                          case 3:
                               return 0x3C;
                          break;
                          case 4:
                               return 0x24;
                          break;
                          case 5:
                               return 0x24;
                          break;
                          case 6:
                               return 0X1C;
                          break;
                          case 7:
                               return 0;
                          break;
                          }
                   break;
                   }
                   }
void main() {
             int c;
             c=0;
             ADCON1 |= 0x0F;
             CMCON  |= 7;
             TRISE=0; // registro
             TRISD=0; //Matriz 1
             TRISB=0; // Matriz 2
             PORTE=0;
             PORTB=0;
             PORTE=0b111;
             Delay_ms(1);
             PORTE=0b100;
             Delay_ms(1);
             PORTE=0b101;
             Delay_ms(1);
             while(1){
                      if(c== 16){
                                  PORTE=0;
                                  PORTE=0b101;
                                  Delay_us(480);
                                  PORTE=0b110;
                                  Delay_us(480);
                                  PORTE=0b111;
                                  Delay_us(480);
                                  c=0;
                                  }
                      else{
                          PORTE=0b100;
                          Delay_us(480);
                          PORTE=0b101;
                          if(c<8){
                                  PORTD=numero(0,c);// Dibuja la A
                                  }
                          else{
                               PORTB=numero(1,c-8);  //Dibuja la B
                               }
                          c++;
                          Delay_us(480);
                          }
                      }
}