int numero(int numero,int fila){
    switch(numero){
                   case 0:
                   switch(fila){
                          case 0:
                                return 0;
                          break;
                          case 1:
                               return 6;
                          break;
                          case 2:
                               return 9;
                          break;
                          case 3:
                               return 9;
                          break;
                          case 4:
                               return 9;
                          break;
                          case 5:
                               return 9;
                          break;
                          case 6:
                               return 6;
                          break;
                          case 7:
                               return 0;
                          break;
                          }
                   break;
                   case 1:
                   switch(fila){
                          case 0:
                                return 4;
                          break;
                          case 1:
                               return 6;
                          break;
                          case 2:
                               return 5;
                          break;
                          case 3:
                               return 4;
                          break;
                          case 4:
                               return 4;
                          break;
                          case 5:
                               return 4;
                          break;
                          case 6:
                               return 4;
                          break;
                          case 7:
                               return 0;
                          break;
                          }
                   break;
                   case 2:
                   switch(fila){
                          case 0:
                                return 0;
                          break;
                          case 1:
                               return 6;
                          break;
                          case 2:
                               return 9;
                          break;
                          case 3:
                               return 4;
                          break;
                          case 4:
                               return 2;
                          break;
                          case 5:
                               return 1;
                          break;
                          case 6:
                               return 0x0F;
                          break;
                          case 7:
                               return 0;
                          break;
                          }
                   break;
                   case 3:
                   switch(fila){
                          case 0:
                                return 6;
                          break;
                          case 1:
                               return 9;
                          break;
                          case 2:
                               return 9;
                          break;
                          case 3:
                               return 4;
                          break;
                          case 4:
                               return 8;
                          break;
                          case 5:
                               return 9;
                          break;
                          case 6:
                               return 6;
                          break;
                          case 7:
                               return 0;
                          break;
                          }
                   break;
                   case 4:
                   switch(fila){
                          case 0:
                                return 0;
                          break;
                          case 1:
                               return 9;
                          break;
                          case 2:
                               return 9;
                          break;
                          case 3:
                               return 9;
                          break;
                          case 4:
                               return 0x0F;
                          break;
                          case 5:
                               return 8;
                          break;
                          case 6:
                               return 8;
                          break;
                          case 7:
                               return 0;
                          break;
                          }
                   break;
                   case 5:
                   switch(fila){
                          case 0:
                                return 0;
                          break;
                          case 1:
                               return 0x0F;
                          break;
                          case 2:
                               return 1;
                          break;
                          case 3:
                               return 7;
                          break;
                          case 4:
                               return 8;
                          break;
                          case 5:
                               return 8;
                          break;
                          case 6:
                               return 7;
                          break;
                          case 7:
                               return 0;
                          break;
                          }
                   break;
                   case 6:
                   switch(fila){
                          case 0:
                                return 0;
                          break;
                          case 1:
                               return 4;
                          break;
                          case 2:
                               return 2;
                          break;
                          case 3:
                               return 1;
                          break;
                          case 4:
                               return 7;
                          break;
                          case 5:
                               return 9;
                          break;
                          case 6:
                               return 9;
                          break;
                          case 7:
                               return 6;
                          break;
                          }
                   break;
                   case 7:
                   switch(fila){
                          case 0:
                                return 0;
                          break;
                          case 1:
                               return 7;
                          break;
                          case 2:
                               return 4;
                          break;
                          case 3:
                               return 4;
                          break;
                          case 4:
                               return 0x0E;
                          break;
                          case 5:
                               return 4;
                          break;
                          case 6:
                               return 4;
                          break;
                          case 7:
                               return 0;
                          break;
                          }
                   break;
                   case 8:
                   switch(fila){
                          case 0:
                                return 0;
                          break;
                          case 1:
                               return 6;
                          break;
                          case 2:
                               return 9;
                          break;
                          case 3:
                               return 9;
                          break;
                          case 4:
                               return 6;
                          break;
                          case 5:
                               return 9;
                          break;
                          case 6:
                               return 9;
                          break;
                          case 7:
                               return 6;
                          break;
                          }
                   break;
                   case 9:
                   switch(fila){
                          case 0:
                                return 0;
                          break;
                          case 1:
                               return 6;
                          break;
                          case 2:
                               return 9;
                          break;
                          case 3:
                               return 9;
                          break;
                          case 4:
                               return 0x0E;
                          break;
                          case 5:
                               return 8;
                          break;
                          case 6:
                               return 8;
                          break;
                          case 7:
                               return 0;
                          break;
                          }
                   break;
                   }
    

}

void main() {
             int c;
             int enb;
             int LM;
             int *temp;
             int num1;
             int num2;
             int RTD;
             int * Luz;
             int num3;
             int num4;
             c=0;
             enb=0;
              ADCON1 |= 0x0A; //an0~4 analogicas
              CMCON  |= 7;
              TRISA  = 0xFF;
             TRISE=0;
             TRISD=0;
             TRISB=0;
             PORTE=0;
             PORTB=0;
             PORTE=0b111;
             Delay_ms(10);
             PORTE=0b100;
             Delay_ms(10);
             PORTE=0b101;
             Delay_ms(10);
             LM= ADC_Read(0);
             temp =(int) (LM*125/256);
             num1=(int)temp%10;
             num2=(int)temp-num1;
             num2=(int)num2/10;
             RTD= ADC_Read(1);
             Luz=(int)(RTD/10);
             num3=(int)Luz%10;
             num4=(int)Luz-num3;
             num4=(int)num4/10;
             while(1){
                      TRISD=0;
                      TRISB=0;
                      if(c== 16){
                                  PORTE=0;
                                  PORTE=0b101;
                                  Delay_us(100);
                                  PORTE=0b110;
                                  Delay_us(100);
                                  PORTE=0b111;
                                  Delay_us(100);
                                  c=0;
                                  LM= ADC_Read(0);
                                  temp =(int) (LM*125/256);
                                  num1=(int)temp%10;
                                  num2=(int)temp-num1;
                                  num2=(int)num2/10;
                                  RTD= ADC_Read(1);
                                  Luz=(int)(RTD/10);
                                  num3=(int)Luz%10;
                                  num4=(int)Luz-num3;
                                  num4=(int)num4/10;
                                  if(enb==0){
                                            enb=1;
                                            }
                                  else{
                                       enb=0;
                                       }
                                  }
                      else{
                          PORTE=0b100;
                          Delay_us(100);
                          PORTE=0b101;
                          if(c<8){
                                 if(enb==0){
                                            PORTD=~numero(num2,c);
                                            }
                                 else{
                                      PORTD=~(numero(num1,c)*16);
                                      }

                                 }
                          else{
                              if(enb==0){
                                         PORTB=~numero(num4,c-8);
                                         }
                              else{
                                   PORTB=~(numero(num3,c-8)*16);
                                   }
                              }
                          c++;
                          Delay_us(100);
                          }
                      }
             }