
// PIC18F2550 Configuration Bit Settings

// 'C' source line config statements

#include <xc.h>

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.

// CONFIG1L
#pragma config PLLDIV = 1       // PLL Prescaler Selection bits (No prescale (4 MHz oscillator input drives PLL directly))
#pragma config CPUDIV = OSC1_PLL2// System Clock Postscaler Selection bits ([Primary Oscillator Src: /1][96 MHz PLL Src: /2])
#pragma config USBDIV = 1       // USB Clock Selection bit (used in Full-Speed USB mode only; UCFG:FSEN = 1) (USB clock source comes directly from the primary oscillator block with no postscale)

// CONFIG1H
#pragma config FOSC = XT_XT     // Oscillator Selection bits (XT oscillator (XT))
#pragma config FCMEN = OFF      // Fail-Safe Clock Monitor Enable bit (Fail-Safe Clock Monitor disabled)
#pragma config IESO = OFF       // Internal/External Oscillator Switchover bit (Oscillator Switchover mode disabled)

// CONFIG2L
#pragma config PWRT = OFF       // Power-up Timer Enable bit (PWRT disabled)
#pragma config BOR = ON         // Brown-out Reset Enable bits (Brown-out Reset enabled in hardware only (SBOREN is disabled))
#pragma config BORV = 3         // Brown-out Reset Voltage bits (Minimum setting)
#pragma config VREGEN = OFF     // USB Voltage Regulator Enable bit (USB voltage regulator disabled)

// CONFIG2H
#pragma config WDT = OFF        // Watchdog Timer Enable bit (WDT disabled (control is placed on the SWDTEN bit))
#pragma config WDTPS = 32768    // Watchdog Timer Postscale Select bits (1:32768)

// CONFIG3H
#pragma config CCP2MX = ON      // CCP2 MUX bit (CCP2 input/output is multiplexed with RC1)
#pragma config PBADEN = ON      // PORTB A/D Enable bit (PORTB<4:0> pins are configured as analog input channels on Reset)
#pragma config LPT1OSC = OFF    // Low-Power Timer 1 Oscillator Enable bit (Timer1 configured for higher power operation)
#pragma config MCLRE = ON       // MCLR Pin Enable bit (MCLR pin enabled; RE3 input pin disabled)

// CONFIG4L
#pragma config STVREN = ON      // Stack Full/Underflow Reset Enable bit (Stack full/underflow will cause Reset)
#pragma config LVP = OFF        // Single-Supply ICSP Enable bit (Single-Supply ICSP disabled)
#pragma config XINST = OFF      // Extended Instruction Set Enable bit (Instruction set extension and Indexed Addressing mode disabled (Legacy mode))

// CONFIG5L
#pragma config CP0 = OFF        // Code Protection bit (Block 0 (000800-001FFFh) is not code-protected)
#pragma config CP1 = OFF        // Code Protection bit (Block 1 (002000-003FFFh) is not code-protected)
#pragma config CP2 = OFF        // Code Protection bit (Block 2 (004000-005FFFh) is not code-protected)
#pragma config CP3 = OFF        // Code Protection bit (Block 3 (006000-007FFFh) is not code-protected)

// CONFIG5H
#pragma config CPB = OFF        // Boot Block Code Protection bit (Boot block (000000-0007FFh) is not code-protected)
#pragma config CPD = OFF        // Data EEPROM Code Protection bit (Data EEPROM is not code-protected)

// CONFIG6L
#pragma config WRT0 = OFF       // Write Protection bit (Block 0 (000800-001FFFh) is not write-protected)
#pragma config WRT1 = OFF       // Write Protection bit (Block 1 (002000-003FFFh) is not write-protected)
#pragma config WRT2 = OFF       // Write Protection bit (Block 2 (004000-005FFFh) is not write-protected)
#pragma config WRT3 = OFF       // Write Protection bit (Block 3 (006000-007FFFh) is not write-protected)

// CONFIG6H
#pragma config WRTC = OFF       // Configuration Register Write Protection bit (Configuration registers (300000-3000FFh) are not write-protected)
#pragma config WRTB = OFF       // Boot Block Write Protection bit (Boot block (000000-0007FFh) is not write-protected)
#pragma config WRTD = OFF       // Data EEPROM Write Protection bit (Data EEPROM is not write-protected)

// CONFIG7L
#pragma config EBTR0 = OFF      // Table Read Protection bit (Block 0 (000800-001FFFh) is not protected from table reads executed in other blocks)
#pragma config EBTR1 = OFF      // Table Read Protection bit (Block 1 (002000-003FFFh) is not protected from table reads executed in other blocks)
#pragma config EBTR2 = OFF      // Table Read Protection bit (Block 2 (004000-005FFFh) is not protected from table reads executed in other blocks)
#pragma config EBTR3 = OFF      // Table Read Protection bit (Block 3 (006000-007FFFh) is not protected from table reads executed in other blocks)

// CONFIG7H
#pragma config EBTRB = OFF      // Boot Block Table Read Protection bit (Boot block (000000-0007FFh) is not protected from table reads executed in other blocks)

#include<p18f2550.h>//Declaracion de librerias
#include<plib/delays.h>

#define pul PORTBbits.RB4 //define el pin del pulsador

void envia(void);// Funcion de enviar dato

int i,constant,cont,contaux=0;// declaracion de constantes globales
int b,tecla =0;// declaracion de constantes globales
int envio=5;// declaracion de constantes globales
float dato;// declaracion de constantes globales
float a;// declaracion de constantes globales
void main()
{
    ADCON1=13;// Declaracion de los 2 primeros puerto como analogos
    ADCON2=128;//Justificacion a la derecha para la conversion

    int aux=0;//Declaracion de auxiliar para guardar los registros
    TRISC=0;//puerto c como salida
    TRISB=16;//5 pin como salida
    TXSTA=36;//habilita envio
    SPBRG=25; // por el flujo de datos configurado
    RCSTA=128;//Habilita recepcion
    BAUDCON=0;// registro de seguridad
    while(1)
    {
            ADCON0 = 3;
            while(ADCON0==3){}//conversion analoga digital canal 1
            aux=(ADRESL|(ADRESH<<8));// guarda conversion en los registros altos y bajos
            a=((aux*4.886)/1023);//conversion a la magnitud fisica
            if(pul==1){// Aumento de la varible pulsador cada vez que se presiona
                while(pul == 1){}
                cont++;
            }

            if(cont==4){//reiniciar variable cuando se a pusaldo 4 veces
                cont=0;
            }

            if(a>1.17 && a<1.95){// posicion del acelerometro en el centro
                constant=0;
            }else if(a<1.16){//posicion del acelerometro en el izq
                constant=1;
            }else if(a>1.96){//posicion del acelerometro en el derecha
                constant=2;
            }else{
                constant=0;
            }

            if(cont==0){//Indica el numero del motor
                PORTB=1;// prenden un puerto segun el motor
            }else if(cont==1){//
                PORTB=2;
            }else if(cont==2){//
                PORTB=4;
            }else if(cont==3){//
                PORTB=8;
            }
            contaux = cont <<2;// toma la variable contador y la mueve 2 posiciones
            envio = constant | contaux;// concatena la variable contador con el valor a enviar para el motor en 32
            envia();// envia el valor
            Delay10KTCYx(4);// delay de espera
    }
}
        void envia(void)
        {

                TXREG= envio;// iguala el registro de salida al valor a enviar
                while(!TXSTAbits.TRMT){}// espera a que envie
                Delay1KTCYx(1);//Delay de seguridad de envio

        }



