void main ()
{
    int capt=0,a=0,b=1,c=0,d=1,e=0,f=2,g=0,h=3;
    ADCON1=15;
    TRISB=240;
    TRISA=0;
    while(1){

    }
}
int teclado() // funcion del teclado
{
    PORTB=1;
    if(PORTB==17){while(PORTB==17){}return 0;}
    else if(PORTB==33){while(PORTB==33){}return 1;}
    else if(PORTB==65){while(PORTB==65){}return 2;}
    else if(PORTB==129){while(PORTB==129){}return 3;}
    PORTB= 2;
    if(PORTB==18){while(PORTB==18){}return 4;}
    else if(PORTB==34){while(PORTB==34){}return 5;}
    else if(PORTB==66){while(PORTB==66){}return 6;}
    else if(PORTB==130){while(PORTB==130){}return 7;}
    PORTB= 4;
    if(PORTB==20){while(PORTB==20){}return 8;}
    else if(PORTB==36){while(PORTB==36){}return 9;}
    else if(PORTB==68){while(PORTB==68){}return 0;}
    else if(PORTB==132){while(PORTB==132){}{return 0;}}
    PORTB= 8;
    if(PORTB==24){while(PORTB==24){}return 0;}
    else if(PORTB==40){while(PORTB==40){}return 0;}
    else if(PORTB==72){while(PORTB==72){}return 0;}
    else if(PORTB==136){while(PORTB==136){}return 0;}
}