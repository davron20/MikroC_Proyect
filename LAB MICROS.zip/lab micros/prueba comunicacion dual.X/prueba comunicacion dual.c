#include<plib.h>
#include<p32xxxx.h>
#include<lega-c/proc/p32mx220f032b.h>
#pragma config FNOSC = FRCPLL // Interna oscilador RC Fast (8 MHz) w / PLL
#pragma config FPLLIDIV = DIV_2 // Dividir FRC antes PLL (ahora 4 MHz)
#pragma config FPLLMUL = MUL_20 // PLL Multiply (ahora 80 MHz)
#pragma config FPLLODIV = DIV_2 // Divide Despu�s de PLL (ahora 40 MHz)
#pragma config FWDTEN = OFF // Watchdog Timer discapacitados
#pragma config ICESEL = ICS_PGx1 // ICE / ICD Comm Channel Select
#pragma config JTAGEN = OFF // Desactivar JTAG
#pragma config FSOSCEN = OFF // Desactivar el Oscilador Secundario
#pragma config FPBDIV = DIV_1 // PBCLK = SYCLK
#define FPB 40000000l
#define BAUD_RATE (FPB/4/9600)-1 // se divide entre 4 por que la velocidad de trasnmision es alta, si fuera baja se dividia en 16


void iniciar_U2(void);
int U2_enviar(int);
char U2_obtener(void);
int U2_disponible(void);

void iniciar_U1(void);
int U1_enviar(int);
char U1_obtener(void);
int U1_disponible(void);

void refresco(void);
void delay_10us(int);

int i;
int a,b,c=50;
int d=50;

void main(){
    int captura_U1,captura_U2 = 0 ;
    int selec,constante=0;
    iniciar_U2();
    iniciar_U1();
    ANSELA=0;
    ANSELB=0;
    ODCA=0;
    TRISA=0;
    TRISB=8448;//256


    while(1){

//        if(U2_disponible()){
//            captura_U2 = U2_obtener();
//            U2_enviar(captura_U2 + 0x30);
//        }
//
//        if(U1_disponible()){
//            captura_U1 = U1_obtener();
//            U1_enviar(captura_U1 + 0x30);
//        }


        if(U2_disponible()){
            captura_U2 = U2_obtener();
        }
        selec = captura_U2 & 12;
        selec = selec>>2;
        constante = captura_U2 & 3;

        if(constante==0){
            if(U1_disponible()){
            captura_U1 = U1_obtener();
            }
            selec = captura_U1 & 12;
            selec = selec>>2;
            constante = captura_U1 & 3;
        }

        if(selec == 0){
            if(constante==0){
                a=a;
            }else if(constante == 1){
                a++;
            }else if(constante == 2){
                a--;
            }
        }else if(selec == 1){
            if(constante==0){
                b=b;
            }else if(constante == 1){
                b++;
            }else if(constante == 2){
                b--;
            }
        }else if(selec == 2){
            if(constante==0){
                c=c;
            }else if(constante == 1){
                c++;
            }else if(constante == 2){
                c--;
            }
        }else if(selec == 3){
            if(constante==0){
                d=d;
            }else if(constante == 1){
                d++;
            }else if(constante == 2){
                d--;
            }
        }

        refresco();

        //U2RXREG = 0;
        U2_enviar(captura_U2 + 0x30);

    }


}

void iniciar_U2(void){

    SYSKEY = 0xAA996655;
    SYSKEY = 0x556699AA;

    RPB9R=2;// TX RPB9
    U2RXR=4;//RX PUERTO RPB8

    SYSKEY = 0;

    U2BRG = BAUD_RATE;
    U2MODE = 0x8008;

    U2STAbits.URXEN = 1;
    U2STAbits.UTXEN = 1;
}

void iniciar_U1(void){

    SYSKEY = 0xAA996655;
    SYSKEY = 0x556699AA;

    RPB15R=1;// TX RPB15
    U1RXR=3;//RX PUERTO RPB13

    SYSKEY = 0;

    U1BRG = BAUD_RATE;
    U1MODE = 0x8008;

    U1STAbits.URXEN = 1;
    U1STAbits.UTXEN = 1;
}

int U2_enviar(int env){
    while (!U2STAbits.TRMT){}
    U2TXREG = env;
    return env;
}

int U1_enviar(int env){
    while (!U1STAbits.TRMT){}
    U1TXREG = env;
    return env;
}

char U2_obtener(void){
    while (!U2STAbits.URXDA){}
    return U2RXREG;
}

char U1_obtener(void){
    while (!U1STAbits.URXDA){}
    return U1RXREG;
}

void delay_10us(int valor){int r;

        for(i=0;i<35*valor;i++){

        }

}

void refresco(){
            PORTA=1;delay_10us(50+a);//Delay10TCYx(50+a);
            PORTA=0;
            PORTA=2;delay_10us(50+b);//Delay10TCYx(50+b);
            PORTA=0;
            PORTA=4;delay_10us(50+c);//Delay10TCYx(50+c);
            PORTA=0;
            PORTA=8;delay_10us(50+d);//Delay10TCYx(50+d);
            PORTA=0;delay_10us(2000);//Delay1KTCYx(20);
}

int U1_disponible(){
    if(U1STAbits.URXDA){return 1;}
    else{
        return 0 ;
    }
}

int U2_disponible(){
    if(U2STAbits.URXDA){return 1;}
    else{
        return 0;
    }
}