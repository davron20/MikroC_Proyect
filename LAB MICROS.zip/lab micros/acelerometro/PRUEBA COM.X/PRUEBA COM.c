#include<plib.h>
#include<p32xxxx.h>
#include<lega-c/proc/p32mx220f032b.h>
#pragma config FNOSC = FRCPLL // Interna oscilador RC Fast (8 MHz) w / PLL
#pragma config FPLLIDIV = DIV_2 // Dividir FRC antes PLL (ahora 4 MHz)
#pragma config FPLLMUL = MUL_20 // PLL Multiply (ahora 80 MHz)
#pragma config FPLLODIV = DIV_2 // Divide Despu�s de PLL (ahora 40 MHz)
#pragma config FWDTEN = OFF // Watchdog Timer discapacitados
#pragma config ICESEL = ICS_PGx1 // ICE / ICD Comm Channel Select
#pragma config JTAGEN = OFF // Desactivar JTAG
#pragma config FSOSCEN = OFF // Desactivar el Oscilador Secundario
#pragma config FPBDIV = DIV_1 // PBCLK = SYCLK
#define FPB 40000000l
#define BAUD_RATE (FPB/4/9600)-1 // se divide entre 4 por que la velocidad de trasnmision es alta, si fuera baja se dividia en 16


void iniciar_U2(void);
int U2_enviar(int);
char U2_obtener(void);

int i;

void main(){
    int captura;
    iniciar_U2();
    ANSELA=0;
    ANSELB=0;
    ODCA=0;
    TRISA=0;
    TRISB=256;

    while(1){
        captura = U2_obtener();;
        U2RXREG = 0;
        U2_enviar(captura);

    }


}

void iniciar_U2(void){

    SYSKEY = 0xAA996655;
    SYSKEY = 0x556699AA;

    RPB9R=2;// TX RPB9
    U2RXR=4;//RX PUERTO RPB1

    SYSKEY = 0;

    U2BRG = BAUD_RATE;
    U2MODE = 0x8008;

    U2STAbits.URXEN = 1;
    U2STAbits.UTXEN = 1;
}

int U2_enviar(int env){
    while (!U2STAbits.TRMT){}
    U2TXREG = env;
    return env;
}

char U2_obtener(void){
    while (!U2STAbits.URXDA){}
    return U2RXREG;
}

void delay_ms(int valor){
    for(i=0;i<valor;i++){
    }
}