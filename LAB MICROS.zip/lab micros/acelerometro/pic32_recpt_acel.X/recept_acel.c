#include<p32xxxx.h>
void config1();
int recepcion();
int envio(int);
#define FREQ 40000000L
#define FPB 40000000L
#define BAUD_RATE (FPB/4/115200)-1
void main(){
    config1();
    ANSELA=0;
    ANSELB=0;
    ODCA=0;
    TRISA=0;
    int a;
    while(1){
        a=recepcion();
        envio(a);
    }
}
void config1(){
  SYSKEY=0XAA996655;
  SYSKEY=0X556699AA;
  RPB0R=2;
  U2RXR=2;
  U2BRG=BAUD_RATE;
  U2MODE=0x8008;
  U2STAbits.UTXEN=1;
  U2STAbits.URXEN=1;
  SYSKEY=0;
  TRISBbits.TRISB1=1;
}
int envio(int a){
    while(U2STAbits.UTXBF);
    U2TXREG = a;
    return a;
}
int recepcion(){
    while(!U2STAbits.URXDA){};
    return U2RXREG;
}
