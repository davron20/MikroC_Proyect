# include<p18f2550.h>
# include<plib/delays.h>
# include <xc.h>
# define rs PORTAbits.RA5
# define e PORTAbits.RA6
void configlcd();
void lcd(int);
void configlcd()
{
    TRISB=0;
    TRISA=0;
    e=1;
    rs =0;
    lcd(0x38);lcd(0x06);lcd(0x0c);
    Delay1KTCYx(10);
    e=0;
}
void lcd(int dato){
    TRISB=0;
    TRISA=0;
    e=1;
    rs=1;
    int aux=0;
    int aux2=0;
    aux=(dato&3)<<3;
    aux=aux+rs+e;
    aux2=dato;
    aux2=252&dato;
    PORTA=aux;
    PORTB=aux2;
    e=0;
}
void main(){
    float a,b,c;
    ADCON1=14;ADCON2=128;TRISB=0;TRISA=1;
    while(1){
        ADCON0=3;while(ADCON0==3);
        a=(ADRESL|(ADRESH<<8))*(500/1023);
        b=(a/100);
        c=()
        lcd(0x30+a);

    }
}
