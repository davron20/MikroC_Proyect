//WHILE 10 24.4 uS 100 240
#include<plib.h>
#include<p32xxxx.h>
#include<lega-c/proc/p32mx220f032b.h>
#pragma config FNOSC = FRCPLL // Interna oscilador RC Fast (8 MHz) w / PLL
#pragma config FPLLIDIV = DIV_2 // Dividir FRC antes PLL (ahora 4 MHz)
#pragma config FPLLMUL = MUL_20 // PLL Multiply (ahora 80 MHz)
#pragma config FPLLODIV = DIV_2 // Divide Despu�s de PLL (ahora 40 MHz)
#pragma config FWDTEN = OFF // Watchdog Timer discapacitados
#pragma config ICESEL = ICS_PGx1 // ICE / ICD Comm Channel Select
#pragma config JTAGEN = OFF // Desactivar JTAG
#pragma config FSOSCEN = OFF // Desactivar el Oscilador Secundario
#pragma config FPBDIV = DIV_1 // PBCLK = SYCLK

#define rs PORTAbits.RA0
#define e PORTAbits.RA1
#define trig PORTAbits.RA2
#define echo PORTAbits.RA3


void configlcd();
void lcd(int a);
int ultrasonido();
int k,capt,b,n=0,h=0;
char dis[]={'D','I','S','T','A','N','C','I','A'};
void main(){int x,y,z,w=0;float capt1;
        TRISA=8;TRISB=0;ANSELA=0;ANSELB=0;
        ODCA=0;
        ODCB=0;
        configlcd();
        while(1){e=1;
            capt=ultrasonido();
            x=capt/1000;
            y=(capt-(x*1000))/100;
            z=(capt-(x*1000)-(y*100))/10;
            w=(capt-(x*1000)-(y*100)-(z*10));
            rs=0;
            lcd(0x80);
            rs=1;
            for(h=0;h<9;h++){
                lcd(dis[h]);
                b=10000;while(b--){}
            }
            rs = 0;
            lcd(0xc5);
            rs = 1;
            b=10000;while(b--){}
            lcd(0x30+x);
            b=10000;while(b--){}
            rs = 0;
            lcd(0xc6);
            rs = 1;
            b=10000;while(b--){}
            lcd(0x30+y);
            b=10000;while(b--){}
            rs = 0;
            lcd(0xc7);
            rs = 1;
            b=10000;while(b--){}
            lcd(0x30+z);
            b=10000;while(b--){}
            rs = 0;
            lcd(0xc8);
            rs = 1;
            b=10000;while(b--){}
            lcd(0x30+w);
            b=10000;while(b--){}

    }
}
void lcd(int a){int aux1=0;
    int aux2=0;
    e=1;
    b=25000;while(b--){}
    aux1 = a;
    aux1 = aux1 & 63;
    aux2 = a;
    aux2 = aux2 & 192;
    aux2 = aux2 << 1;
    PORTB = aux1 | aux2 ;
    b=15000;while(b--){}
    e=0;
    b=15000;while(b--){}
}
void configlcd(){
    TRISB=0;
    rs =0;
    lcd(0x38);lcd(0x06);lcd(0x0c);
    b=4167;while(b--){}
}
int ultrasonido(){float cont;
    trig=1;
    b=40;while(b--){}
    trig=0;
    while(echo == 0){}
    while(echo == 1){cont++;}
    cont=0.017*cont;
    cont=cont*7.4/5;
    cont=cont*10;
    return cont;
}