#include<P18f2550.h>
#include<xc.h>
#include<stdint.h>

#define CS1 PORTAbits.RA0
#define CS2 PORTAbits.RA1
#define RS PORTAbits.RA2
#define E PORTAbits.RA3
#define _XTAL_FREQ 4000000
void SelectChip(int chip){
    CS1 = chip;
    CS2 = !chip;
}
void Clock_pulse(){
    E=1;
    __delay_us(4);
    E=0;
}
void eviarcomando(int cmd){
    __delay_ms(2);
    RS=0;
    //E=0;
    PORTB=cmd;
    Clock_pulse();
    //PORTB=0x0;
}
void enviardato(int data){
    RS=1;
    E=0;
    PORTB = data;
    Clock_pulse();
    PORTB=0;

}
void GLCD_Init(){
   //PORTB=0x0;
SelectChip(0);
eviarcomando(0x3E);
eviarcomando(0xC0);
eviarcomando(0xB8);
eviarcomando(0x40);
eviarcomando(0x3F);
SelectChip(1);
eviarcomando(0x3E);
eviarcomando(0xC0);
eviarcomando(0xB8);
eviarcomando(0x40);
eviarcomando(0x3F);
}
void clear(){
    for(int j=0;j<8;j++){
        SelectChip(0);
        eviarcomando(0xB8 | j);
        for (int i=0;i<64;i++){
            enviardato(0x0);
        }
        SelectChip(1);
        eviarcomando(0xB8 | j);
        for (int i=0;i<64;i++){
            enviardato(0x0);
        }
    }
}
void main (){
    ADCON1=15;
    TRISB=0;
    TRISA=0;
    while (1){
        GLCD_Init();
        clear();
        int f=128;
        int y=0;
        int g=0;
        int z=0;
        int j=0;
        int w=0;
        for(int x=0;x<8;x++)
        {
        SelectChip(0);
        eviarcomando(0xB8 | x);
        for(y=z;y<j;y++)
        {
            if ((y%8)==0){enviardato(f);}
            else{
           w=f/g;
           enviardato(w);}
           g=g+2;
           __delay_ms(100);
        }
        z=z+8;
        j=z+8;

       }
    }
}